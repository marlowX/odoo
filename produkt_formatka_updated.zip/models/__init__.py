from . import furniture_config
from . import product_template
from . import stock_rules
from . import furniture_bom
